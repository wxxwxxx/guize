const ruleUpdateUtil = require('scripts/ruleUpdateUtil');

function siriRun() {
    
}

function renderSiriUI() {
    $intents.height = 100
}

module.exports = {
    siriRun: siriRun,
    renderSiriUI: renderSiriUI
}